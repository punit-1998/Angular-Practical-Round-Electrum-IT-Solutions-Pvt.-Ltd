import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  addUserForm !: FormGroup;
  submitted: boolean = false;
  uploadedFile: any;
  @Output() userData: EventEmitter<any> = new EventEmitter<any>();

  constructor(private fb: FormBuilder, private _ApiService: ApiService) {
    this.formBuild()
  }

  ngOnInit(): void {
  }

  formBuild() {
    this.addUserForm = this.fb.group({
      first_name: ['punit', [Validators.required]],
      last_name: ['adsf', Validators.required],
      email: ['asdf@gmail.com', [Validators.required,Validators.email]]
    });
  }

  get _form() {
    return this.addUserForm.controls;
  }

  uploadFile(event: any) {
    if (event) { this.uploadedFile = event.target.files[0] }
  }

  addUser() {
    this.submitted = true
    if (this.addUserForm.invalid) {
      return;
    }

    const formData = this.addUserForm.value
    let url = "https://reqres.in/api/users"
    this._ApiService.post(url, formData).subscribe({
      next: (response) => {
        console.log(response);
        this.uploadedFile = ''
        this.addUserForm.reset();
        this.submitted = false
        this.userData.emit(response);
      },
      error: (error) => {
        this.submitted = false
      },
      complete: () => {
      }
    })

  }

}
