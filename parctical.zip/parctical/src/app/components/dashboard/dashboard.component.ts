import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],

})
export class DashboardComponent implements OnInit {

  allUserData: any;
  user: any;
  showModal: boolean = false;
  @ViewChild('addUserModal')
  addUserModal!: ElementRef;

  constructor(private _ApiService: ApiService, private router: Router,private renderer: Renderer2) {
    const loginUser = localStorage.getItem('loginUser');
    this.user = loginUser ? JSON.parse(loginUser) : {};
  }

  ngOnInit(): void {
    this.getAllUser()
  }

  getAllUser() {
    let url = "https://reqres.in/api/users?page=2"

    this._ApiService.get(url).subscribe({
      next: (response) => {
        console.log(response);
        this.allUserData = response.data
      },
      error: (error) => {
        console.error(error);
      },
      complete: () => {
      }
    })
  }

  logout() {
    localStorage.removeItem('loginUser');
    this.router.navigate([''])
  }

  addUser() {
    this.showModal = true;
  }

  onUserDataReceived(data: any) {
    // const myModalEl: any = document.getElementById('exampleModal')
    
    // myModalEl.addEventListener('hidden.bs.modal', (event: any) => {
    //   console.log(event)
    // })


    this.renderer.removeClass(this.addUserModal.nativeElement, 'show');
    this.renderer.setStyle(this.addUserModal.nativeElement, 'display', 'none');
    this.renderer.removeClass(document.body, 'modal-open');
    const modalBackdrop = document.querySelector('.modal-backdrop');
    if (modalBackdrop) {
      modalBackdrop.remove();
    }
    
    this.allUserData.push(data)
  }


  deleteUser(id:any) {
    if(!id)
    {
      return
    }  

    let url = `https://reqres.in/api/users/${id}`

    this._ApiService.delete(url).subscribe({
      next: (response) => {
        
      },
      error: (error) => {
        console.error(error);
      },
      complete: () => {
        
      }
    })
  }


}
