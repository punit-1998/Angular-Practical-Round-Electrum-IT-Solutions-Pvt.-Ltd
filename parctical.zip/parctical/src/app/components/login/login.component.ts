import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm !: FormGroup;
  submitted : boolean = false;
  isLogin : boolean = false

  constructor(private fb : FormBuilder,private router: Router) { 
    this.formBuild();

    const loginUser = localStorage.getItem('loginUser');
    if(loginUser){this.isLogin = true}
  }

  ngOnInit(): void {

  }

  formBuild()
  {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  get _form()
  {
    return this.loginForm.controls;
  }

  login() {
    this.submitted = true
    if (this.loginForm.invalid) {
      return;
    }

    const email = this.loginForm.value.email;
    const password = this.loginForm.value.password;

    const users = JSON.parse(localStorage.getItem('users') || '[]' ) as any[];

    const user = users.find((user: any) => user.email === email && user.password === password);

    if (user) {
      localStorage.setItem('loginUser',JSON.stringify(user))
      this.router.navigate(['/dashboard']);
    } else {
      alert('Invalid email or password!');
    }
  }

}
