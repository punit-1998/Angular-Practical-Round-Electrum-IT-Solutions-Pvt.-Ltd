import {
  Component,
} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  user:any;

  constructor() {
      this.user = localStorage.getItem("users");
      if(!this.user)
      {
          var initialUsers = [
            { email: "user1@gmail.com", password: "123" , name : "user1" },
            { email: "user2@gmail.com", password: "123" , name : "user2" },
            { email: "user3@gmail.com", password: "123" , name : "user3" },
            { email: "user4@gmail.com", password: "123" , name : "user4" },
            { email: "user5@gmail.com", password: "123" , name : "user5" }
          ];
          localStorage.setItem("users",JSON.stringify(initialUsers))
      }
    }
 }
